
import React, { useState } from 'react';
import { PastMatch, PastIndividualMatch } from '../types';

interface HistoryScreenProps {
  pastMatches: PastMatch[];
  pastIndividualMatches: PastIndividualMatch[];
  onLoadPastMatch: (pastMatch: PastMatch) => void;
  onDeletePastMatch: (id: number) => void;
  onDeletePastIndividualMatch: (id: number) => void;
  onBack: () => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({
  pastMatches,
  pastIndividualMatches,
  onLoadPastMatch,
  onDeletePastMatch,
  onDeletePastIndividualMatch,
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<'team' | 'individual'>('team');

  const TeamMatchHistory = () => (
    <div className="space-y-3">
      {pastMatches.length > 0 ? (
        pastMatches.map(match => (
          <div key={match.id} className="bg-[#FFFEFD] p-3 rounded-lg shadow-sm border border-gray-200 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
            <div className="flex-grow">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-bold text-gray-800">
                  {match.tournamentInfo.name || '練習試合'}
                  {match.tournamentInfo.round && <span className="text-gray-600 font-normal"> - {match.tournamentInfo.round}</span>}
                </p>
                {match.finalResult && (
                    <span className="text-xs font-bold bg-yellow-400 text-yellow-900 px-2 py-0.5 rounded-full">{match.finalResult}</span>
                )}
              </div>
              <p className="text-sm text-gray-600">{match.teamA.name} vs {match.teamB.name} - <span className="font-semibold">{match.winnerTeamName}</span></p>
              <p className="text-xs text-gray-400 mt-1">{new Date(match.timestamp).toLocaleString()}</p>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <button onClick={() => onLoadPastMatch(match)} className="px-4 py-2 text-sm font-semibold bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">再表示</button>
              <button onClick={() => onDeletePastMatch(match.id)} className="px-4 py-2 text-sm font-semibold bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">削除</button>
            </div>
          </div>
        ))
      ) : (
        <p className="text-gray-500 text-center py-4">保存された団体戦の結果はありません。</p>
      )}
    </div>
  );

  const IndividualMatchHistory = () => (
     <div className="space-y-3">
      {pastIndividualMatches.length > 0 ? (
        pastIndividualMatches.map(pMatch => {
          const { match } = pMatch;
          const winnerName = match.winner === 'A' ? match.playerA.name : match.winner === 'B' ? match.playerB.name : '引分';
          return (
            <div key={pMatch.id} className="bg-[#FFFEFD] p-3 rounded-lg shadow-sm border border-gray-200 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                <div className="flex-grow">
                    <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-bold text-gray-800">
                          {match.tournamentInfo.name || '練習試合'}
                          {match.tournamentInfo.round && <span className="text-gray-600 font-normal"> - {match.tournamentInfo.round}</span>}
                        </p>
                        {pMatch.finalResult && (
                            <span className="text-xs font-bold bg-yellow-400 text-yellow-900 px-2 py-0.5 rounded-full">{pMatch.finalResult}</span>
                        )}
                    </div>
                    <p className="text-sm text-gray-600">{match.playerA.name} vs {match.playerB.name} - <span className="font-semibold">{winnerName} の勝利</span></p>
                    <p className="text-xs text-gray-400 mt-1">{new Date(pMatch.timestamp).toLocaleString()}</p>
                </div>
                 <div className="flex gap-2 flex-shrink-0">
                    <button onClick={() => onDeletePastIndividualMatch(pMatch.id)} className="px-4 py-2 text-sm font-semibold bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">削除</button>
                </div>
            </div>
          )
        })
      ) : (
        <p className="text-gray-500 text-center py-4">保存された個人戦の結果はありません。</p>
      )}
    </div>
  );

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#f8f6f2] p-2 sm:p-4">
      <header className="text-center mb-6 mt-8 sm:mt-12">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-gray-800 tracking-tight">試合履歴</h1>
        <p className="text-gray-500 mt-2">過去の試合結果を再表示または削除できます</p>
      </header>
      <main className="bg-[#FFFEFD] rounded-2xl shadow-lg p-4 sm:p-8 md:p-10 w-full max-w-4xl">
        <div className="border-b border-gray-200 mb-4">
          <nav className="-mb-px flex space-x-6" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('team')}
              className={`${
                activeTab === 'team'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-lg`}
            >
              団体戦
            </button>
            <button
              onClick={() => setActiveTab('individual')}
              className={`${
                activeTab === 'individual'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-lg`}
            >
              個人戦
            </button>
          </nav>
        </div>
        <div className="w-full text-left bg-[#f8f6f2] border border-gray-200 rounded-lg p-4 max-h-[60vh] overflow-y-auto">
          {activeTab === 'team' ? <TeamMatchHistory /> : <IndividualMatchHistory />}
        </div>
        <div className="mt-8 flex justify-center">
            <button onClick={onBack} className="w-full sm:w-auto px-12 py-3 bg-gray-600 text-white font-bold rounded-lg hover:bg-gray-700 transition-colors text-lg">
                トップに戻る
            </button>
        </div>
      </main>
       <footer className="text-center mt-12 text-gray-500 text-sm">
        <p>Created by Maika</p>
      </footer>
    </div>
  );
};
