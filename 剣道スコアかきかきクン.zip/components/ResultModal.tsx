
import React, { useState } from 'react';
import { TeamSummary } from '../types';

interface ResultModalProps {
  isOpen: boolean;
  onSaveAndClose: (finalResult: string) => void;
  onEdit: () => void;
  onSaveAndReset: (finalResult: string) => void;
  onSaveAndNextMatch: (finalResult: string) => void;
  onDaihyosen: () => void;
  teamAName: string;
  teamBName: string;
  teamASummary: TeamSummary;
  teamBSummary: TeamSummary;
  daihyosenFinished: boolean;
  onAnalysis: () => void;
  analysis: string | null;
  isAnalyzing: boolean;
  didHomeTeamWin: boolean;
}

export const ResultModal: React.FC<ResultModalProps> = ({
  isOpen,
  onSaveAndClose,
  onEdit,
  onSaveAndReset,
  onSaveAndNextMatch,
  onDaihyosen,
  teamAName,
  teamBName,
  teamASummary,
  teamBSummary,
  daihyosenFinished,
  onAnalysis,
  analysis,
  isAnalyzing,
  didHomeTeamWin,
}) => {
  const [finalResult, setFinalResult] = useState('');

  if (!isOpen) return null;

  let winnerText = '';
  let isTie = false;

  if (teamASummary.wins > teamBSummary.wins) {
    winnerText = `${teamAName} の勝利！`;
  } else if (teamBSummary.wins > teamASummary.wins) {
    winnerText = `${teamBName} の勝利！`;
  } else {
    if (teamASummary.ippons > teamBSummary.ippons) {
      winnerText = `${teamAName} の勝利！ (本数勝)`;
    } else if (teamBSummary.ippons > teamASummary.ippons) {
      winnerText = `${teamBName} の勝利！ (本数勝)`;
    } else {
      isTie = true;
      winnerText = '引き分け';
    }
  }
  
  const winnerColorClass = winnerText.includes(teamAName) ? 'text-gray-800' : winnerText.includes(teamBName) ? 'text-red-500' : 'text-yellow-500';
  const showAnalysisButton = (!isTie || daihyosenFinished) && !analysis && !isAnalyzing;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
       <datalist id="final-results-list">
        <option value="優勝" />
        <option value="準優勝" />
        <option value="三位" />
        <option value="ベスト8" />
        <option value="ベスト16" />
        <option value="敢闘賞" />
        <option value="予選リーグ敗退" />
      </datalist>
      <div className="bg-[#FFFEFD] text-gray-800 rounded-xl p-5 sm:p-8 max-w-md w-full border-2 border-yellow-400 shadow-2xl">
        <h2 className="text-2xl sm:text-3xl font-bold text-center text-yellow-500 mb-4">試合結果 (Result)</h2>
        <div className="text-center my-6">
          <p className={`text-2xl sm:text-4xl font-bold ${winnerColorClass}`}>{winnerText}</p>
        </div>
        <div className="flex justify-around text-center mb-6 sm:mb-8 text-sm sm:text-base">
            <div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-800">{teamAName}</h3>
                <p>勝ち数: {teamASummary.wins}</p>
                <p>取得本数: {teamASummary.ippons}</p>
            </div>
            <div>
                <h3 className="text-lg sm:text-xl font-bold text-red-500">{teamBName}</h3>
                <p>勝ち数: {teamBSummary.wins}</p>
                <p>取得本数: {teamBSummary.ippons}</p>
            </div>
        </div>

        <div className="mb-4">
            <label htmlFor="finalResult" className="block text-sm font-bold text-gray-600 mb-1 text-center">最終成績 (任意)</label>
            <input
                id="finalResult"
                type="text"
                value={finalResult}
                onChange={(e) => setFinalResult(e.target.value)}
                list="final-results-list"
                placeholder="例: 優勝、三位"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
            />
        </div>

        <div className="flex flex-col gap-3">
          {isTie && !daihyosenFinished && (
            <button
              onClick={onDaihyosen}
              className="w-full bg-yellow-500 text-gray-900 font-bold py-2.5 px-4 rounded-lg hover:bg-yellow-400 transition-colors text-base sm:text-lg"
            >
              代表選へ (Tie-breaker)
            </button>
          )}

          {(showAnalysisButton || isAnalyzing) && (
             <button
              onClick={onAnalysis}
              disabled={isAnalyzing}
              className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold py-2.5 px-4 rounded-lg hover:from-purple-600 hover:to-indigo-700 transition-all text-base sm:text-lg shadow-md disabled:opacity-50 disabled:cursor-wait"
            >
              {isAnalyzing ? '分析中...' : 'AIによる分析 (Analyze with AI)'}
            </button>
          )}

          {analysis && !isAnalyzing && (
            <div className="mt-2 p-4 bg-[#f8f6f2] rounded-lg border border-gray-200 animate-fade-in">
              <h4 className="font-bold text-purple-700 mb-2">AI 分析 (AI Analysis)</h4>
              <p className="text-gray-700 whitespace-pre-wrap text-sm">{analysis}</p>
            </div>
          )}

          <button
            onClick={onEdit}
            className="w-full bg-orange-500 text-white font-bold py-2.5 px-4 rounded-lg hover:bg-orange-600 transition-colors text-base sm:text-lg"
          >
            試合を編集 (Edit Match)
          </button>

          {didHomeTeamWin ? (
              <button
                onClick={() => onSaveAndNextMatch(finalResult)}
                className="w-full bg-blue-600 text-white font-bold py-2.5 px-4 rounded-lg hover:bg-blue-500 transition-colors text-base sm:text-lg"
              >
                保存して次の対戦へ (Save & Next)
              </button>
          ) : (
              <button
                onClick={() => onSaveAndReset(finalResult)}
                className="w-full bg-blue-600 text-white font-bold py-2.5 px-4 rounded-lg hover:bg-blue-500 transition-colors text-base sm:text-lg"
              >
                保存して新しい試合へ (Save & New)
              </button>
          )}
           <button
            onClick={() => onSaveAndClose(finalResult)}
            className="w-full bg-gray-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-500 transition-colors"
          >
            保存して閉じる (Save & Close)
          </button>
        </div>
      </div>
    </div>
  );
};
