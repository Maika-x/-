

import React, { useState, useMemo } from 'react';
import { IndividualMatch, IndividualMatchType, MatchStatus, SavedTeam, Player } from '../types';
import { CustomDropdown } from './CustomDropdown';

interface IndividualMatchSetupProps {
  onSetupComplete: (match: IndividualMatch) => void;
  onBack: () => void;
  savedTeams: SavedTeam[];
  onSkipIndividualSetup: () => void;
}

export const IndividualMatchSetup: React.FC<IndividualMatchSetupProps> = ({ onSetupComplete, onBack, savedTeams, onSkipIndividualSetup }) => {
  const [step, setStep] = useState(1);
  
  // Step 1: Tournament Info & Roster
  const [tournamentName, setTournamentName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [venue, setVenue] = useState('');
  const [roster, setRoster] = useState<Player[]>([
    { name: '', affiliation: '' },
    { name: '', affiliation: '' },
  ]);

  // Step 2: Match Config
  const [selectedWhitePlayerIndex, setSelectedWhitePlayerIndex] = useState<number | null>(null);
  const [selectedRedPlayerIndex, setSelectedRedPlayerIndex] = useState<number | null>(null);
  const [matchType, setMatchType] = useState<IndividualMatchType>('SANBON');
  const [round, setRound] = useState('');

  const allPlayerNames = useMemo(() => {
    const names = new Set<string>();
    savedTeams.forEach(team => {
        team.members.forEach(member => { if (member.name) names.add(member.name); });
        team.substitutes.forEach(sub => { if (sub.name) names.add(sub.name); });
    });
    return Array.from(names);
  }, [savedTeams]);
  
  const allAffiliationNames = useMemo(() => {
    const affiliations = new Set<string>();
    savedTeams.forEach(team => {
        if (team.name) affiliations.add(team.name);
        team.members.forEach(member => { if (member.affiliation) affiliations.add(member.affiliation); });
        team.substitutes.forEach(sub => { if (sub.affiliation) affiliations.add(sub.affiliation); });
    });
    return Array.from(affiliations);
  }, [savedTeams]);

  const handleRosterChange = (index: number, field: keyof Player, value: string) => {
    setRoster(prev => prev.map((p, i) => i === index ? { ...p, [field]: value } : p));
  };
  
  const handleAddPlayer = () => {
    setRoster(prev => [...prev, { name: '', affiliation: '' }]);
  };
  
  const handleRemovePlayer = (index: number) => {
    setRoster(prev => prev.filter((_, i) => i !== index));
  };

  const handleLoadFromTeam = (teamId: string) => {
    if (!teamId) return;
    const team = savedTeams.find(t => t.id === teamId);
    if (team) {
      const teamPlayers = [...team.members, ...team.substitutes];
      const existingNames = new Set(roster.map(p => p.name).filter(Boolean));
      const newPlayers = teamPlayers.filter(p => p.name && !existingNames.has(p.name));
      // Remove the initial empty players if they are still empty
      const updatedRoster = roster.filter(p => p.name.trim() !== '' || p.affiliation.trim() !== '');
      setRoster([...updatedRoster, ...newPlayers]);
    }
  };

  const handleNextStep = () => {
    const namedPlayerIndices = roster.map((p, i) => p.name.trim() !== '' ? i : -1).filter(i => i !== -1);
    
    if (namedPlayerIndices.length > 0) {
        setSelectedWhitePlayerIndex(namedPlayerIndices[0]);
        setSelectedRedPlayerIndex(namedPlayerIndices.length > 1 ? namedPlayerIndices[1] : namedPlayerIndices[0]);
    } else {
        setSelectedWhitePlayerIndex(null);
        setSelectedRedPlayerIndex(null);
    }

    setStep(2);
  };

  const handleStart = () => {
    const activeRoster = roster.filter(p => p.name.trim() !== '');

    // Validation: if roster has players, selections must be made.
    if (activeRoster.length > 0) {
        if (selectedWhitePlayerIndex === null || selectedRedPlayerIndex === null) {
            alert('白と赤、両方の選手を選択してください。');
            return;
        }
        if (selectedWhitePlayerIndex === selectedRedPlayerIndex && activeRoster.length > 1) {
            alert('白と赤には異なる選手を選択してください。');
            return;
        }
    }

    const getPlayer = (index: number | null, defaultName: string): Player => {
        if (index === null) {
            return { name: defaultName, affiliation: '' };
        }
        return roster[index];
    };

    let playerA = getPlayer(selectedWhitePlayerIndex, '選手1');
    let playerB = getPlayer(selectedRedPlayerIndex, '選手2');

    // Handle case where the same (single) player is selected for both roles
    if (selectedWhitePlayerIndex !== null && selectedWhitePlayerIndex === selectedRedPlayerIndex) {
        playerB = { name: '選手2', affiliation: '' };
    }

    const match: IndividualMatch = {
      tournamentInfo: {
        name: tournamentName.trim() || '個人戦 (Individual Match)',
        date: eventDate || new Date().toISOString().split('T')[0],
        venue: venue.trim(),
        round: round.trim() || undefined,
      },
      playerA, // White
      playerB, // Red
      points: [],
      status: MatchStatus.PENDING,
      matchType,
    };
    onSetupComplete(match);
  };

  const renderStep1 = () => (
    <>
      <datalist id="all-players-list">{allPlayerNames.map(name => <option key={name} value={name} />)}</datalist>
      <datalist id="all-affiliations-list">{allAffiliationNames.map(name => <option key={name} value={name} />)}</datalist>
      <div className="w-full space-y-6 text-left">
        <fieldset className="space-y-4 p-4 border rounded-lg bg-[#f8f6f2]/50">
          <legend className="text-xl font-bold text-gray-700 px-2">ステップ1: 大会と選手の情報</legend>
          <div>
            <label htmlFor="tournamentName" className="block font-bold text-gray-600 mb-2">大会名 (任意)</label>
            <input id="tournamentName" type="text" value={tournamentName} onChange={(e) => setTournamentName(e.target.value)} placeholder="例: 全日本剣道選手権大会" className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="eventDate" className="block font-bold text-gray-600 mb-2">開催年月日</label>
                <input id="eventDate" type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                  <label htmlFor="venue" className="block font-bold text-gray-600 mb-2">開催地</label>
                  <input id="venue" type="text" value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="例: 日本武道館" className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
          </div>
        </fieldset>

        <fieldset className="space-y-4 p-4 border rounded-lg bg-[#f8f6f2]/50">
          <legend className="text-xl font-bold text-gray-700 px-2">選手名簿 (Player Roster)</legend>
          <div>
            <label htmlFor="load-from-team" className="block font-bold text-gray-600 mb-2">保存済みチームから読込</label>
            <select
                id="load-from-team"
                onChange={(e) => handleLoadFromTeam(e.target.value)}
                className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            >
                <option value="">チームを選択...</option>
                {savedTeams.map(team => <option key={team.id} value={team.id}>{team.name}</option>)}
            </select>
          </div>
          <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
            {roster.map((player, index) => (
              <div key={index} className="flex items-center gap-2 p-3 bg-[#FFFEFD] border border-gray-200 rounded-lg">
                <span className="font-bold text-gray-500">{index + 1}.</span>
                <div className="flex-grow grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input type="text" value={player.name} onChange={(e) => handleRosterChange(index, 'name', e.target.value)} placeholder="選手名" className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" list="all-players-list" />
                  <input type="text" value={player.affiliation} onChange={(e) => handleRosterChange(index, 'affiliation', e.target.value)} placeholder="所属 (任意)" className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" list="all-affiliations-list" />
                </div>
                <button onClick={() => handleRemovePlayer(index)} className="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-bold text-xl leading-none flex-shrink-0 self-center" aria-label={`Remove player ${index + 1}`}>-</button>
              </div>
            ))}
          </div>
          <button onClick={handleAddPlayer} className="text-blue-600 hover:text-blue-700 font-semibold transition-colors mt-2">+ 選手を追加</button>
        </fieldset>
      </div>
      <div className="mt-10 flex flex-col-reverse sm:flex-row sm:justify-between items-center gap-4">
        <button onClick={onBack} className="w-full sm:w-auto px-8 py-4 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors text-lg">戻る</button>
        <div className="w-full sm:flex-1 flex flex-col gap-3">
          <button
            onClick={handleNextStep}
            className="w-full px-6 py-3 text-lg sm:px-8 sm:py-4 sm:text-xl bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            次へ (対戦設定)
          </button>
          <button onClick={onSkipIndividualSetup} className="w-full px-4 py-2 bg-gray-600 text-white font-bold rounded-lg hover:bg-gray-700 transition-colors text-base">
            設定をスキップして試合を開始
          </button>
        </div>
      </div>
    </>
  );

  const renderStep2 = () => {
    const availablePlayers = roster
        .map((p, index) => ({ player: p, originalIndex: index }))
        .filter(item => item.player.name.trim() !== '');
    
    const playerOptions = availablePlayers.map(item => ({
        value: String(item.originalIndex),
        label: `${item.player.name} ${item.player.affiliation ? `(${item.player.affiliation})` : ''}`
    }));

    const roundOptions = [
        { value: "", label: "選択してください" },
        { value: "予選リーグ", label: "予選リーグ (Prelim. League)" },
        { value: "一回戦", label: "一回戦 (1st Round)" },
        { value: "二回戦", label: "二回戦 (2nd Round)" },
        { value: "三回戦", label: "三回戦 (3rd Round)" },
        { value: "四回戦", label: "四回戦 (4th Round)" },
        { value: "五回戦", label: "五回戦 (5th Round)" },
        { value: "六回戦", label: "六回戦 (6th Round)" },
        { value: "七回戦", label: "七回戦 (7th Round)" },
        { value: "準々決勝", label: "準々決勝 (Quarter-final)" },
        { value: "準決勝", label: "準決勝 (Semi-final)" },
        { value: "決勝", label: "決勝 (Final)" },
        { value: "順位決定戦", label: "順位決定戦 (Ranking Match)" },
    ];
    
    const matchTypeOptions = [
        { value: 'SANBON', label: '三本勝負 (Sanbon Shobu)' },
        { value: 'IPPON', label: '一本勝負 (Ippon Shobu)' },
    ];

    return (
        <>
            <div className="w-full space-y-6 text-left">
                <fieldset className="space-y-6 p-4 border rounded-lg bg-[#f8f6f2]/50">
                    <legend className="text-xl font-bold text-gray-700 px-2">ステップ2: 対戦カード設定</legend>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 items-end">
                        <div className="space-y-2">
                             <label htmlFor="white-player" className="block font-bold text-gray-800">白 (White)</label>
                             <CustomDropdown id="white-player" options={playerOptions} value={selectedWhitePlayerIndex !== null ? String(selectedWhitePlayerIndex) : ''} onChange={(v) => setSelectedWhitePlayerIndex(Number(v))} placeholder="選手を選択" />
                        </div>
                         <div className="space-y-2">
                             <label htmlFor="red-player" className="block font-bold text-red-500">赤 (Red)</label>
                             <CustomDropdown id="red-player" options={playerOptions} value={selectedRedPlayerIndex !== null ? String(selectedRedPlayerIndex) : ''} onChange={(v) => setSelectedRedPlayerIndex(Number(v))} placeholder="選手を選択" />
                        </div>
                         <div className="space-y-2">
                            <label htmlFor="round" className="block font-bold text-gray-600">回戦 (Round)</label>
                            <CustomDropdown id="round" options={roundOptions} value={round} onChange={setRound} placeholder="選択してください" />
                        </div>
                        <div className="space-y-2">
                            <label htmlFor="matchType" className="block font-bold text-gray-600">試合形式 (Match Type)</label>
                            <CustomDropdown id="matchType" options={matchTypeOptions} value={matchType} onChange={(v) => setMatchType(v as IndividualMatchType)} />
                        </div>
                    </div>
                </fieldset>
            </div>
            <div className="mt-10 flex flex-col sm:flex-row-reverse gap-4">
                <button onClick={handleStart} className="w-full flex-1 px-6 py-3 text-lg sm:px-8 sm:py-4 sm:text-xl bg-green-600 text-white font-bold rounded-lg shadow-md hover:bg-green-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">試合開始 (Start Match)</button>
                <button onClick={() => setStep(1)} className="w-full sm:w-auto px-8 py-4 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors text-lg">戻る</button>
            </div>
        </>
    );
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#f8f6f2] p-2 sm:p-4">
      <header className="text-center mb-6">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-gray-800 tracking-tight">個人戦設定</h1>
      </header>
      <main className="bg-[#FFFEFD] rounded-2xl shadow-lg p-4 sm:p-8 md:p-10 text-center w-full max-w-3xl">
        {step === 1 ? renderStep1() : renderStep2()}
      </main>
      <footer className="text-center mt-12 text-gray-500 text-sm">
        <p>Created by Maika</p>
      </footer>
    </div>
  );
};
