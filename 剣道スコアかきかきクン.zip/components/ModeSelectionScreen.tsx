
import React from 'react';

interface ModeSelectionScreenProps {
  onStartTeamMatch: () => void;
  onStartIndividualMatch: () => void;
  onViewHistory: () => void;
}

export const ModeSelectionScreen: React.FC<ModeSelectionScreenProps> = ({ onStartTeamMatch, onStartIndividualMatch, onViewHistory }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#f8f6f2] p-4">
      <header className="text-center mb-12 mt-8 sm:mt-16">
        <h1 className="font-title text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-normal text-indigo-800 py-2 leading-tight">
          剣道スコア<br/>かきかきクン
        </h1>
      </header>

      <main className="w-full max-w-md text-center">
        <h2 className="text-2xl font-bold text-gray-700 mb-6">メニューを選択してください</h2>
        <div className="flex flex-col gap-5">
          <button
            onClick={onStartTeamMatch}
            className="w-full px-6 py-4 text-xl sm:px-8 sm:py-5 sm:text-2xl bg-blue-600 text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            団体戦を始める
            <span className="block text-sm font-normal opacity-90">Start Team Match</span>
          </button>
          <button
            onClick={onStartIndividualMatch}
            className="w-full px-6 py-4 text-xl sm:px-8 sm:py-5 sm:text-2xl bg-green-600 text-white font-bold rounded-xl shadow-lg hover:bg-green-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            個人戦を始める
             <span className="block text-sm font-normal opacity-90">Start Individual Match</span>
          </button>
          <button
            onClick={onViewHistory}
            className="w-full px-6 py-4 text-xl sm:px-8 sm:py-5 sm:text-2xl bg-teal-600 text-white font-bold rounded-xl shadow-lg hover:bg-teal-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
          >
            試合履歴を見る
             <span className="block text-sm font-normal opacity-90">View Match History</span>
          </button>
        </div>
      </main>

      <footer className="text-center mt-16 text-gray-500 text-sm">
        <p>Created by Maika</p>
      </footer>
    </div>
  );
};
