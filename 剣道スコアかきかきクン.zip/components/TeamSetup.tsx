



import React, { useState, useEffect, useMemo } from 'react';
import { SavedTeam, TournamentInfo, Player, TeamMatchFormat } from '../types';
import { TEAM_COMPOSITIONS, UI_TEXT } from '../constants';
import { CustomDropdown } from './CustomDropdown';

export interface HomeTeamSetup {
  id?: string;
  teamData: Omit<SavedTeam, 'id'>;
  gameMode: 3 | 5 | 7;
  color: 'red' | 'white';
}

export interface OpponentTeamSetup {
  id?: string;
  teamData: Omit<SavedTeam, 'id'>;
}

interface TeamSetupProps {
  savedTeams: SavedTeam[];
  setSavedTeams: React.Dispatch<React.SetStateAction<SavedTeam[]>>;
  onSetupComplete: (
    tournamentInfo: TournamentInfo,
    homeTeamConfig: HomeTeamSetup,
    opponentTeamConfig: OpponentTeamSetup,
    matchFormat: TeamMatchFormat
  ) => void;
  onSkipSetup: () => void;
  onBack: () => void;
  teamToContinue: { team: SavedTeam, gameMode: 3 | 5 | 7, matchFormat: TeamMatchFormat } | null;
}

const TeamEditor: React.FC<{
  title: string;
  savedTeams: SavedTeam[];
  selectedTeamId: string;
  onSelectTeam: (id: string) => void;
  onDeleteTeam: (id:string) => void;
  teamName: string;
  onTeamNameChange: (name: string) => void;
  members: Player[];
  onMemberChange: (index: number, field: keyof Player, value: string) => void;
  substitutes: Player[];
  onSubstituteChange: (index: number, field: keyof Player, value: string) => void;
  addSubstitute: () => void;
  removeSubstitute: (index: number) => void;
  gameMode: 3 | 5 | 7;
}> = ({ title, savedTeams, selectedTeamId, onSelectTeam, onDeleteTeam, teamName, onTeamNameChange, members, onMemberChange, substitutes, onSubstituteChange, addSubstitute, removeSubstitute, gameMode }) => {
  const allPlayerNames = useMemo(() => {
    const names = new Set<string>();
    savedTeams.forEach(team => {
        team.members.forEach(member => { if (member.name) names.add(member.name); });
        team.substitutes.forEach(sub => { if (sub.name) names.add(sub.name); });
    });
    return Array.from(names);
  }, [savedTeams]);
  
  const allAffiliationNames = useMemo(() => {
    const affiliations = new Set<string>();
    savedTeams.forEach(team => {
        if (team.name) affiliations.add(team.name);
        team.members.forEach(member => { if (member.affiliation) affiliations.add(member.affiliation); });
        team.substitutes.forEach(sub => { if (sub.affiliation) affiliations.add(sub.affiliation); });
    });
    return Array.from(affiliations);
  }, [savedTeams]);
  
  return (
    <div className="w-full space-y-4 text-left p-4 sm:p-6 border border-gray-200 rounded-lg bg-[#f8f6f2]">
      <datalist id="all-players-list">
        {allPlayerNames.map(name => <option key={name} value={name} />)}
      </datalist>
      <datalist id="all-affiliations-list">
        {allAffiliationNames.map(name => <option key={name} value={name} />)}
      </datalist>
      <h3 className="text-lg sm:text-xl font-bold text-gray-700">{title}</h3>
      <div>
        <label htmlFor={`${title}-load`} className="block font-bold text-gray-600 mb-2">保存済みチームから読込</label>
        <div className="flex items-center gap-2">
            <select
              id={`${title}-load`}
              value={selectedTeamId}
              onChange={(e) => onSelectTeam(e.target.value)}
              className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 flex-grow"
            >
              <option value="new">新しいチームを作成</option>
              {savedTeams.map(team => (
                <option key={team.id} value={team.id}>{team.name}</option>
              ))}
            </select>
            {selectedTeamId !== 'new' && (
                <button 
                    onClick={() => onDeleteTeam(selectedTeamId)} 
                    className="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-bold text-base sm:text-lg flex-shrink-0" 
                    aria-label="Delete selected team"
                >
                    削除
                </button>
            )}
        </div>
      </div>
      <div>
        <label htmlFor={`${title}-name`} className="block font-bold text-gray-600 mb-2">チーム名</label>
        <input id={`${title}-name`} type="text" value={teamName} onChange={(e) => onTeamNameChange(e.target.value)} className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
      </div>
      <div>
        <h4 className="font-bold text-gray-600 mb-2">レギュラー選手 ({gameMode}人)</h4>
        <div className="space-y-3">
          {TEAM_COMPOSITIONS[gameMode].positions.map((position, index) => (
            <div key={index} className="p-3 bg-[#FFFEFD] border border-gray-200 rounded-lg">
              <label htmlFor={`${title}-member-name-${index}`} className="block text-sm font-bold text-gray-500 mb-1">{position}</label>
              <input 
                id={`${title}-member-name-${index}`} 
                type="text" value={members[index]?.name || ''} 
                onChange={(e) => onMemberChange(index, 'name', e.target.value)} 
                placeholder={`${TEAM_COMPOSITIONS[gameMode].placeholders[index]}`} 
                className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base sm:text-lg" 
                list="all-players-list"
              />
              <input 
                id={`${title}-member-affiliation-${index}`} 
                type="text" value={members[index]?.affiliation || ''} 
                onChange={(e) => onMemberChange(index, 'affiliation', e.target.value)} 
                placeholder="所属 (任意)" 
                className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm" 
                list="all-affiliations-list"
              />
            </div>
          ))}
        </div>
      </div>
      <div>
        <h4 className="font-bold text-gray-600 mb-2">補欠選手</h4>
        <div className="space-y-2">
          {substitutes.map((sub, index) => (
            <div key={index} className="flex items-center gap-2 p-3 bg-[#FFFEFD] border border-gray-200 rounded-lg">
              <div className="flex-grow">
                <input 
                  type="text" 
                  value={sub.name} 
                  onChange={(e) => onSubstituteChange(index, 'name', e.target.value)} 
                  placeholder={`補欠 ${index + 1}`} 
                  className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base sm:text-lg"
                  list="all-players-list"
                />
                 <input 
                  type="text" 
                  value={sub.affiliation || ''} 
                  onChange={(e) => onSubstituteChange(index, 'affiliation', e.target.value)} 
                  placeholder="所属 (任意)" 
                  className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  list="all-affiliations-list"
                />
              </div>
              <button onClick={() => removeSubstitute(index)} className="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-bold text-xl leading-none flex-shrink-0 self-center" aria-label="Remove substitute">-</button>
            </div>
          ))}
        </div>
        <button onClick={addSubstitute} className="mt-3 text-blue-600 hover:text-blue-700 font-semibold transition-colors">+ 補欠選手を追加</button>
      </div>
    </div>
  );
};

export const TeamSetup: React.FC<TeamSetupProps> = ({ savedTeams, setSavedTeams, onSetupComplete, onSkipSetup, onBack, teamToContinue }) => {
  const [step, setStep] = useState(1);
  const [showContinueConfirm, setShowContinueConfirm] = useState(!!teamToContinue);


  // Step 1: Tournament Info
  const [tournamentName, setTournamentName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [venue, setVenue] = useState('');
  const [round, setRound] = useState('');

  // Step 2: Your Team
  const [yourTeamId, setYourTeamId] = useState('new');
  const [yourTeamName, setYourTeamName] = useState('');
  const [gameMode, setGameMode] = useState<3 | 5 | 7>(5);
  const [matchFormat, setMatchFormat] = useState<TeamMatchFormat>(teamToContinue?.matchFormat || 'POINT_MATCH');
  const [yourMembers, setYourMembers] = useState<Player[]>(() => Array.from({ length: 5 }, () => ({ name: '', affiliation: '' })));
  const [yourSubs, setYourSubs] = useState<Player[]>([{ name: '', affiliation: '' }]);

  // Step 3: Opponent Team
  const [opponentTeamId, setOpponentTeamId] = useState('new');
  const [opponentName, setOpponentName] = useState('');
  const [opponentMembers, setOpponentMembers] = useState<Player[]>(() => Array.from({ length: 5 }, () => ({ name: '', affiliation: '' })));
  const [opponentSubs, setOpponentSubs] = useState<Player[]>([{ name: '', affiliation: '' }]);

  // Step 4: Match Config
  const [yourTeamColor, setYourTeamColor] = useState<'white' | 'red'>('white');

  const createDefaultMembers = (size: number) => Array.from({ length: size }, () => ({ name: '', affiliation: '' }));
  const createDefaultSubs = () => [{ name: '', affiliation: '' }];

  // --- Team State Management ---

  useEffect(() => {
    // This effect runs when coming from the "Next Match" flow
    if (teamToContinue && step === 1) {
       // Pre-fill tournament info if available from previous match
      setTournamentName(teamToContinue.team.name); // Example: carry over team name as tournament name
      setMatchFormat(teamToContinue.matchFormat);
      // Auto-skip to step 2 to show the continue confirmation
      setStep(2);
    }
  }, [teamToContinue, step]);

  useEffect(() => {
    if (showContinueConfirm) return;
    const newSize = gameMode;
    const resize = (current: Player[]): Player[] => {
        const newArr = Array.from({ length: newSize }, (_, i) => current[i] || { name: '', affiliation: '' });
        return newArr;
    };
    if (yourTeamId === 'new') {
      setYourMembers(resize);
    }
    if (opponentTeamId === 'new') {
      setOpponentMembers(resize);
    }
  }, [gameMode, yourTeamId, opponentTeamId, showContinueConfirm]);

  useEffect(() => {
    if (showContinueConfirm) return;
    if (yourTeamId === 'new') return;
    const team = savedTeams.find(t => t.id === yourTeamId);
    if (team) {
      setYourTeamName(team.name);
      const newMembers = Array.from({ length: gameMode }, (_, i) => team.members[i] || { name: '', affiliation: '' });
      setYourMembers(newMembers);
      setYourSubs(team.substitutes.length > 0 ? team.substitutes : createDefaultSubs());
    }
  }, [yourTeamId, gameMode, savedTeams, showContinueConfirm]);

  useEffect(() => {
    if (showContinueConfirm) return;
    if (yourTeamId === 'new') {
      setYourTeamName('');
      setYourMembers(createDefaultMembers(gameMode));
      setYourSubs(createDefaultSubs());
    }
  }, [yourTeamId, gameMode, showContinueConfirm]);

  useEffect(() => {
    if (opponentTeamId === 'new') return;
    const team = savedTeams.find(t => t.id === opponentTeamId);
    if (team) {
      setOpponentName(team.name);
      const newMembers = Array.from({ length: gameMode }, (_, i) => team.members[i] || { name: '', affiliation: '' });
      setOpponentMembers(newMembers);
      setYourSubs(team.substitutes.length > 0 ? team.substitutes : createDefaultSubs());
    }
  }, [opponentTeamId, gameMode, savedTeams]);

  useEffect(() => {
    if (opponentTeamId === 'new') {
      setOpponentName('');
      setOpponentMembers(createDefaultMembers(gameMode));
      setOpponentSubs(createDefaultSubs());
    }
  }, [opponentTeamId, gameMode]);

  const handleNextStep = () => setStep(s => s + 1);
  const handleBackStep = () => setStep(s => s - 1);

  const handleDeleteTeam = (teamIdToDelete: string) => {
      if (window.confirm('このチームを本当に削除しますか？選手データも失われます。')) {
        setSavedTeams(prev => prev.filter(t => t.id !== teamIdToDelete));
        if (yourTeamId === teamIdToDelete) setYourTeamId('new');
        if (opponentTeamId === teamIdToDelete) setOpponentTeamId('new');
      }
  };

  const handleStartMatch = () => {
    const trimPlayer = (p: Player) => ({ name: p.name.trim(), affiliation: (p.affiliation || '').trim() });

    // The team set up in Step 2 is considered the "home" team for data structure purposes.
    const homeTeamSetup: HomeTeamSetup = {
      id: yourTeamId !== 'new' ? yourTeamId : undefined,
      teamData: {
        name: yourTeamName.trim() || (yourTeamColor === 'red' ? UI_TEXT.TEAM_RED_DEFAULT : UI_TEXT.TEAM_WHITE_DEFAULT),
        members: yourMembers.map(trimPlayer),
        substitutes: yourSubs.filter(s => s.name.trim() !== '').map(trimPlayer),
      },
      gameMode,
      color: yourTeamColor,
    };

    const opponentTeamSetup: OpponentTeamSetup = {
      id: opponentTeamId !== 'new' ? opponentTeamId : undefined,
      teamData: {
        name: opponentName.trim() || (yourTeamColor === 'red' ? UI_TEXT.TEAM_WHITE_DEFAULT : UI_TEXT.TEAM_RED_DEFAULT),
        members: opponentMembers.map(trimPlayer),
        substitutes: opponentSubs.filter(s => s.name.trim() !== '').map(trimPlayer),
      },
    };

    onSetupComplete({ name: tournamentName.trim(), date: eventDate, venue: venue.trim(), round: round.trim() || undefined }, homeTeamSetup, opponentTeamSetup, matchFormat);
  };
  
  const gameModeOptions = [
    { value: '7', label: '7人制 (7-Player Team)' },
    { value: '5', label: '5人制 (5-Player Team)' },
    { value: '3', label: '3人制 (3-Player Team)' },
  ];

  const matchFormatOptions = [
    { value: 'POINT_MATCH', label: '団体戦' },
    { value: 'KACHI_NUKI', label: '抜戦' },
  ];
  
  const roundOptions = [
        { value: "", label: "選択してください" },
        { value: "予選リーグ", label: "予選リーグ (Prelim. League)" },
        { value: "一回戦", label: "一回戦 (1st Round)" },
        { value: "二回戦", label: "二回戦 (2nd Round)" },
        { value: "三回戦", label: "三回戦 (3rd Round)" },
        { value: "四回戦", label: "四回戦 (4th Round)" },
        { value: "五回戦", label: "五回戦 (5th Round)" },
        { value: "六回戦", label: "六回戦 (6th Round)" },
        { value: "七回戦", label: "七回戦 (7th Round)" },
        { value: "準々決勝", label: "準々決勝 (Quarter-final)" },
        { value: "準決勝", label: "準決勝 (Semi-final)" },
        { value: "決勝", label: "決勝 (Final)" },
        { value: "順位決定戦", label: "順位決定戦 (Ranking Match)" },
    ];
    
  const handleConfirmContinue = () => {
    if (!teamToContinue) return;
    const { team, gameMode: prevGameMode, matchFormat: prevMatchFormat } = teamToContinue;

    setGameMode(prevGameMode);
    setMatchFormat(prevMatchFormat);
    setYourTeamId(team.id || 'new');
    setYourTeamName(team.name);
    
    const newMembers = Array.from({ length: prevGameMode }, (_, i) => team.members[i] || { name: '', affiliation: '' });
    setYourMembers(newMembers);
    
    setYourSubs(team.substitutes.length > 0 ? [...team.substitutes] : createDefaultSubs());
    
    setShowContinueConfirm(false);
    // Automatically move to opponent selection
    setStep(3);
  };

  const handleDenyContinue = () => {
    setShowContinueConfirm(false);
  };
  
  const ContinueConfirmModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in">
        <div className="bg-[#FFFEFD] rounded-xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center">
            <h3 className="text-xl font-bold text-gray-800 mb-4">次の対戦へ</h3>
            <p className="text-gray-600 mb-6">「{teamToContinue?.team.name}」として、次の対戦に進みますか？</p>
            <div className="flex justify-center gap-4">
                <button onClick={handleConfirmContinue} className="w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors">はい (Yes)</button>
                <button onClick={handleDenyContinue} className="w-full px-6 py-3 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors">いいえ (No)</button>
            </div>
        </div>
    </div>
  );


  const renderStep1 = () => (
    <>
      <h2 className="text-2xl font-bold text-gray-700 mb-2">ステップ1: 大会の情報</h2>
      <p className="text-gray-500 mb-8">大会情報を入力してください（任意）</p>
      <div className="w-full space-y-4 text-left">
        <div>
          <label htmlFor="tournamentName" className="block font-bold text-gray-600 mb-2">大会名</label>
          <input id="tournamentName" type="text" value={tournamentName} onChange={(e) => setTournamentName(e.target.value)} placeholder="例: 全日本剣道選手権大会" className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="eventDate" className="block font-bold text-gray-600 mb-2">開催年月日</label>
              <input id="eventDate" type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
                <label htmlFor="venue" className="block font-bold text-gray-600 mb-2">開催地</label>
                <input id="venue" type="text" value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="例: 日本武道館" className="w-full px-3 py-2 sm:px-4 sm:py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
        </div>
         <div>
            <label htmlFor="round" className="block font-bold text-gray-600 mb-2">回戦 (任意)</label>
            <CustomDropdown id="round" options={roundOptions} value={round} onChange={setRound} placeholder="選択してください" />
        </div>
      </div>

      <div className="mt-10 flex flex-col-reverse sm:flex-row sm:justify-between items-center gap-4">
        <button onClick={onBack} className="w-full sm:w-auto px-8 py-4 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors text-lg">戻る</button>
        <div className="w-full sm:flex-1 flex flex-col gap-3">
            <button onClick={handleNextStep} className="w-full px-6 py-3 text-lg sm:px-8 sm:py-4 sm:text-xl bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                次へ (チーム設定)
            </button>
            <button onClick={onSkipSetup} className="w-full px-4 py-2 bg-gray-600 text-white font-bold rounded-lg hover:bg-gray-700 transition-colors text-base">
                または、設定をスキップして試合を開始
            </button>
        </div>
      </div>
    </>
  );

  const renderStep2 = () => (
    <>
      <h2 className="text-2xl font-bold text-gray-700 mb-2">ステップ2: あなたのチーム設定</h2>
      <p className="text-gray-500 mb-8">最初に試合形式を選択し、次にチーム情報を入力してください</p>
      
      <div className="w-full space-y-6 text-left mb-8">
        <div>
          <h3 className="font-bold text-gray-600 mb-3">試合形式</h3>
            <CustomDropdown
                id="matchFormat"
                options={matchFormatOptions}
                value={matchFormat}
                onChange={(v) => setMatchFormat(v as TeamMatchFormat)}
            />
        </div>
        <div>
          <h3 className="font-bold text-gray-600 mb-3">人数</h3>
           <CustomDropdown
                id="gameMode"
                options={gameModeOptions}
                value={String(gameMode)}
                onChange={(v) => setGameMode(parseInt(v, 10) as 3 | 5 | 7)}
            />
        </div>
      </div>
      
      <TeamEditor
        title="あなたのチーム"
        savedTeams={savedTeams}
        selectedTeamId={yourTeamId}
        onSelectTeam={setYourTeamId}
        onDeleteTeam={handleDeleteTeam}
        teamName={yourTeamName}
        onTeamNameChange={setYourTeamName}
        members={yourMembers}
        onMemberChange={(i, f, v) => setYourMembers(m => m.map((p, mi) => mi === i ? { ...p, [f]: v } : p))}
        substitutes={yourSubs}
        onSubstituteChange={(i, f, v) => setYourSubs(s => s.map((p, si) => si === i ? { ...p, [f]: v } : p))}
        addSubstitute={() => setYourSubs(s => [...s, { name: '', affiliation: '' }])}
        removeSubstitute={i => setYourSubs(s => s.filter((_, si) => si !== i))}
        gameMode={gameMode}
      />
      <div className="mt-10 flex flex-col sm:flex-row-reverse gap-4">
        <button onClick={handleNextStep} className="w-full flex-1 px-6 py-3 text-lg sm:px-8 sm:py-4 sm:text-xl bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">次へ</button>
        <button onClick={handleBackStep} className="w-full sm:w-auto px-8 py-4 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors text-lg">戻る</button>
      </div>
    </>
  );
  
  const renderStep3 = () => (
     <>
      <h2 className="text-2xl font-bold text-gray-700 mb-2">ステップ3: 対戦相手チーム設定</h2>
      <p className="text-gray-500 mb-8">対戦相手を読込むか、新しいチーム情報を入力してください</p>
      <TeamEditor
        title="対戦チーム"
        savedTeams={savedTeams}
        selectedTeamId={opponentTeamId}
        onSelectTeam={setOpponentTeamId}
        onDeleteTeam={handleDeleteTeam}
        teamName={opponentName}
        onTeamNameChange={setOpponentName}
        members={opponentMembers}
        onMemberChange={(i, f, v) => setOpponentMembers(m => m.map((p, mi) => mi === i ? { ...p, [f]: v } : p))}
        substitutes={opponentSubs}
        onSubstituteChange={(i, f, v) => setOpponentSubs(s => s.map((p, si) => si === i ? { ...p, [f]: v } : p))}
        addSubstitute={() => setOpponentSubs(s => [...s, { name: '', affiliation: '' }])}
        removeSubstitute={i => setOpponentSubs(s => s.filter((_, si) => si !== i))}
        gameMode={gameMode}
      />
      <div className="mt-10 flex flex-col sm:flex-row-reverse gap-4">
        <button onClick={handleNextStep} className="w-full flex-1 px-6 py-3 text-lg sm:px-8 sm:py-4 sm:text-xl bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">次へ (対戦設定)</button>
        <button onClick={handleBackStep} className="w-full sm:w-auto px-8 py-4 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors text-lg">戻る</button>
      </div>
    </>
  );

  const renderStep4 = () => (
    <>
      <h2 className="text-2xl font-bold text-gray-700 mb-2">ステップ4: 対戦設定</h2>
      <p className="text-gray-500 mb-8">チームの立順（サイド）を選択してください</p>

      <div className="bg-[#f8f6f2] border border-gray-200 rounded-lg p-6 space-y-6">
        <div className="flex justify-around items-center text-center">
            <div className="font-bold text-xl text-gray-800">
                <p className="text-sm text-gray-500 mb-1">あなたのチーム</p>
                {yourTeamName.trim() || 'チーム1'}
            </div>
            <div className="text-gray-400 font-bold text-2xl">VS</div>
            <div className="font-bold text-xl text-red-500">
                 <p className="text-sm text-gray-500 mb-1">対戦チーム</p>
                {opponentName.trim() || 'チーム2'}
            </div>
        </div>

        <div>
          <h3 className="font-bold text-gray-600 mb-3 text-center">あなたのチームの立順 (Your Team's Side)</h3>
          <div className="flex justify-center gap-4">
            <button 
                onClick={() => setYourTeamColor('white')} 
                className={`w-full py-2.5 text-lg sm:py-3 sm:text-xl font-bold rounded-lg transition-all border-4 ${yourTeamColor === 'white' ? 'bg-gray-800 text-white border-black' : 'bg-white text-gray-800 border-gray-800 hover:bg-gray-100'}`}
            >
                白 (左側)
            </button>
            <button 
                onClick={() => setYourTeamColor('red')} 
                className={`w-full py-2.5 text-lg sm:py-3 sm:text-xl font-bold rounded-lg transition-all border-4 ${yourTeamColor === 'red' ? 'bg-red-500 text-white border-red-700' : 'bg-white text-red-500 border-red-500 hover:bg-red-50'}`}
            >
                赤 (右側)
            </button>
          </div>
        </div>
      </div>

      <div className="mt-10 flex flex-col sm:flex-row-reverse gap-4">
        <button onClick={handleStartMatch} className="w-full flex-1 px-6 py-3 text-lg sm:px-8 sm:py-4 sm:text-xl bg-green-600 text-white font-bold rounded-lg shadow-md hover:bg-green-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">試合開始 (Start Match)</button>
        <button onClick={handleBackStep} className="w-full sm:w-auto px-8 py-4 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors text-lg">戻る</button>
      </div>
    </>
  );


  return (
     <div className="flex flex-col items-center justify-center min-h-screen bg-[#f8f6f2] p-2 sm:p-4">
      {showContinueConfirm && <ContinueConfirmModal />}
      <header className="text-center mb-6">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-gray-800 tracking-tight">団体戦設定</h1>
      </header>
      <main className="bg-[#FFFEFD] rounded-2xl shadow-lg p-4 sm:p-8 md:p-10 text-center w-full max-w-4xl transition-all duration-300">
        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
        {step === 4 && renderStep4()}
      </main>
      <footer className="text-center mt-12 text-gray-500 text-sm">
        <p>Created by Maika</p>
        <style>{`
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            .animate-fade-in {
                animation: fadeIn 0.3s ease-out;
            }
        `}</style>
      </footer>
    </div>
  );
};