
import React, { useState } from 'react';
import { CalculatedMatch, MatchStatus, TeamSummary, PointType, ScoredPoint, CalculatedMatchWinner, SavedTeam, Player, TeamMatchFormat } from '../types';
import { UI_TEXT, POINT_TYPE_DETAILS, ALL_POINT_TYPES, MATCH_STATUS_TEXT } from '../constants';
import { CustomDropdown } from './CustomDropdown';

// --- Helper Components ---

const TeamSummaryDisplay: React.FC<{
  teamName: string;
  summary: TeamSummary;
  isWinner: boolean;
  isLoser: boolean;
  teamColorClass: string;
}> = ({ teamName, summary, isWinner, isLoser, teamColorClass }) => {
    const shapeSize = "w-24 h-24";
    
    const scoreContent = (
         <div className="flex flex-col items-center justify-center font-bold text-gray-800">
            <div className="flex items-baseline gap-1" title="取得本数">
              <span className="text-2xl leading-none">{summary.ippons}</span>
              <span className="text-sm text-gray-600 font-normal">本</span>
            </div>
            <div className="w-10 h-px bg-gray-500 my-1"></div>
            <div className="flex items-baseline gap-1" title="勝ち数">
              <span className="text-2xl leading-none">{summary.wins}</span>
              <span className="text-sm text-gray-600 font-normal">勝</span>
            </div>
        </div>
    );

    let shape;
    if (isWinner) {
        shape = <svg viewBox="0 0 100 100" className="w-full h-full text-red-500"><circle cx="50" cy="50" r="48" stroke="currentColor" strokeWidth="5" fill="none" /></svg>;
    } else if (isLoser) {
        shape = <svg viewBox="0 0 100 100" className="w-full h-full text-red-500"><polygon points="50,5 95,90 5,90" stroke="currentColor" strokeWidth="5" fill="none" /></svg>;
    } else { // Draw or pending
        return (
             <div className="flex flex-col items-center justify-center h-full gap-2 py-2">
                <div className={`font-bold text-lg sm:text-xl ${teamColorClass}`}>{teamName}</div>
                {scoreContent}
            </div>
        );
    }

    return (
         <div className="flex flex-col items-center justify-center h-full gap-2 py-2">
            <div className={`font-bold text-lg sm:text-xl ${teamColorClass}`}>{teamName}</div>
            <div className={`relative ${shapeSize} flex items-center justify-center`}>
                {shape}
                <div className="absolute inset-0 flex items-center justify-center">{scoreContent}</div>
            </div>
        </div>
    );
}

const EditableCell: React.FC<{ value: string; onChange: (value: string) => void; isFinished: boolean, placeholder?: string, className?: string }> = ({ value, onChange, isFinished, placeholder, className }) => (
    <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={isFinished}
        placeholder={placeholder}
        className={`w-full bg-transparent text-center font-bold p-1 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500 disabled:bg-transparent ${className}`}
    />
);

const PlayerSelect: React.FC<{
  currentPlayer: Player;
  availablePlayers: Player[];
  onChange: (newPlayer: Player) => void;
  isFinished: boolean;
  className?: string;
}> = ({ currentPlayer, availablePlayers, onChange, isFinished, className }) => {
  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedName = e.target.value;
    const selectedPlayer = availablePlayers.find(p => p.name === selectedName);
    onChange(selectedPlayer || { name: selectedName, affiliation: '' });
  };

  return (
    <select
      value={currentPlayer.name}
      onChange={handleSelectChange}
      disabled={isFinished}
      className={`w-full bg-transparent text-center font-bold text-lg sm:text-xl p-1 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500 disabled:bg-transparent disabled:text-gray-500 appearance-none ${className}`}
    >
      {/* Add a hidden option for the current player if they're not in the available list (e.g., custom name for Daihyosen) */}
      {!availablePlayers.some(p => p.name === currentPlayer.name) && currentPlayer.name &&
        <option value={currentPlayer.name} disabled hidden>{currentPlayer.name}</option>
      }
      <option value=""></option>
      {availablePlayers.map((player, idx) => (
        player.name && <option key={`${player.name}-${idx}`} value={player.name}>{player.name}</option>
      ))}
    </select>
  );
};

const IpponDisplay: React.FC<{ points: ScoredPoint[], firstIpponId: number | null, resultText: string | null }> = ({ points, firstIpponId, resultText }) => {
    // Special handling for Fusen (win by forfeit), which is considered a two-point win.
    if (points.some(p => p.type === PointType.FUSEN)) {
        return (
            <div className="flex items-center justify-center h-8">
                {/* Representing a two-point win with two circles */}
                <span className="font-bold text-lg inline-flex items-center justify-center">○○</span>
            </div>
        );
    }

    const ippons = points.filter(p => p.type !== PointType.HANSOKU);
    const showVerticalText = resultText === '一本勝';

    return (
        <div className="flex items-center justify-center h-8 space-x-1">
            {/* Ippons (e.g., M, K) */}
            <div className="flex items-center justify-center space-x-2">
                {ippons.map((point) => {
                    const details = POINT_TYPE_DETAILS[point.type];
                    if (!details) return null;
                    
                    const isFirst = point.id === firstIpponId;

                    return (
                        <span 
                            key={point.id} 
                            className={`inline-flex items-center justify-center w-6 h-6 sm:w-7 sm:h-7 text-sm font-bold ${isFirst ? 'border-2 border-current rounded-full' : ''}`} 
                            title={details.name}
                        >
                            {details.label}
                        </span>
                    );
                })}
            </div>
            {/* Vertical text (e.g., Ippon-gachi) */}
            {showVerticalText && (
                 <div style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }} className="text-xs font-bold text-gray-500 h-full flex items-center">
                    {resultText}
                </div>
            )}
        </div>
    );
};

const FoulDisplay: React.FC<{ points: ScoredPoint[] }> = ({ points }) => {
    const fouls = points.filter(p => p.type === PointType.HANSOKU);
    return (
        <div className="flex items-center justify-center h-6 space-x-1" aria-label={`Fouls: ${fouls.length}`}>
            {fouls.map(foul => (
                <span key={foul.id} className="text-xl text-gray-800" title="Hansoku">▲</span>
            ))}
        </div>
    );
};

const MatchResultMarker: React.FC<{ winner: CalculatedMatchWinner, resultText: string | null }> = ({ winner, resultText }) => {
    const isEncho = resultText === MATCH_STATUS_TEXT[MatchStatus.ENCHO] || resultText === MATCH_STATUS_TEXT[MatchStatus.ENCHO_HIKIWAKE];

    const MarkerContent = () => {
        // If there's a specific result text (like Hantei, Fusen), display it.
        if (resultText && winner !== 'Draw' && !isEncho && resultText !== '一本勝') {
            return (
                <div className="w-full h-full flex items-center justify-center font-bold text-gray-700 text-sm sm:text-lg" aria-label={resultText}>
                    {resultText}
                </div>
            );
        }

        // For a draw, show 'X'. The "Encho" badge is handled separately.
        if (winner === 'Draw') {
            const isEnchoDraw = resultText === MATCH_STATUS_TEXT[MatchStatus.ENCHO_HIKIWAKE];
            if (isEnchoDraw) {
                 return (
                    <div className="relative w-full h-full" aria-label="Draw">
                        <div className="absolute top-1/2 left-0 w-full h-1 bg-red-500 transform -translate-y-1/2 rotate-45 rounded-full"></div>
                        <div className="absolute top-1/2 left-0 w-full h-1 bg-red-500 transform -translate-y-1/2 -rotate-45 rounded-full"></div>
                    </div>
                 );
            }
             // Don't show X for regular encho draw until it's set to ENCHO_HIKIWAKE
            if (resultText !== MATCH_STATUS_TEXT[MatchStatus.ENCHO]) {
                 return (
                    <div className="relative w-full h-full" aria-label="Draw">
                        <div className="absolute top-1/2 left-0 w-full h-1 bg-red-500 transform -translate-y-1/2 rotate-45 rounded-full"></div>
                        <div className="absolute top-1/2 left-0 w-full h-1 bg-red-500 transform -translate-y-1/2 -rotate-45 rounded-full"></div>
                    </div>
                );
            }
        }

        const boxClasses = "flex items-center justify-center w-full h-full border-2 rounded-lg overflow-hidden";
        const winnerBoxClasses = `${boxClasses} border-gray-400`;
        const pendingBoxClasses = `${boxClasses} border-gray-300`;

        return (
            <div className={winner === null ? pendingBoxClasses : winnerBoxClasses}>
                <div className={`flex-1 h-full flex items-center justify-center border-r-2 ${winner === null ? 'border-gray-300' : 'border-gray-400'}`}>
                    {winner === 'A' && <span className="text-gray-800 font-extrabold text-3xl sm:text-4xl">○</span>}
                </div>
                <div className="flex-1 h-full flex items-center justify-center">
                    {winner === 'B' && <span className="text-red-500 font-extrabold text-3xl sm:text-4xl">○</span>}
                </div>
            </div>
        );
    };
    
    return (
        <div className="relative w-16 sm:w-20 h-10 flex items-center justify-center">
             {isEncho && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-500 text-white text-xs font-bold px-2 py-0.5 rounded-full shadow z-10">
                    {MATCH_STATUS_TEXT[MatchStatus.ENCHO]}
                </div>
            )}
             <MarkerContent />
        </div>
    );
};


const InlineScoreControl: React.FC<{
    match: CalculatedMatch;
    matchIndex: number;
    isDaihyosen: boolean;
    isFinished: boolean;
    onAddPoint: (index: number, player: 'A' | 'B', type: PointType, isDaihyosen: boolean) => void;
    onUndoPoint: (index: number, player: 'A' | 'B', isDaihyosen: boolean) => void;
    matchFormat: TeamMatchFormat;
}> = ({ match, matchIndex, isDaihyosen, isFinished, onAddPoint, onUndoPoint, matchFormat }) => {
    const [selectedPointA, setSelectedPointA] = useState<PointType>(PointType.MEN);
    const [selectedPointB, setSelectedPointB] = useState<PointType>(PointType.MEN);
    
    const ippons = match.points.filter(p => p.type !== PointType.HANSOKU);
    const firstIpponInMatch = ippons.length > 0 ? ippons.reduce((earliest, current) => current.id < earliest.id ? current : earliest) : null;
    const firstIpponId = firstIpponInMatch?.id ?? null;

    const pointsA = match.points.filter(p => p.player === 'A');
    const pointsB = match.points.filter(p => p.player === 'B');
    
    const isMatchActionable = !isFinished && (match.status === MatchStatus.PENDING || match.status === MatchStatus.ENCHO);
    const pointLimit = matchFormat === 'KACHI_NUKI' ? 1 : 2;


    const directIpponsA = pointsA.filter(p => p.type !== PointType.HANSOKU).length;
    const canScoreMoreIpponA = isDaihyosen ? directIpponsA < 1 : directIpponsA < pointLimit;
    const canAddPointA = isMatchActionable && (selectedPointA === PointType.HANSOKU || canScoreMoreIpponA);
    const canUndoA = pointsA.length > 0 && isMatchActionable;

    const directIpponsB = pointsB.filter(p => p.type !== PointType.HANSOKU).length;
    const canScoreMoreIpponB = isDaihyosen ? directIpponsB < 1 : directIpponsB < pointLimit;
    const canAddPointB = isMatchActionable && (selectedPointB === PointType.HANSOKU || canScoreMoreIpponB);
    const canUndoB = pointsB.length > 0 && isMatchActionable;

    return (
        <div className="w-full h-full flex items-center justify-between gap-1 sm:gap-2 px-1">
            <div className="flex-1 flex items-center justify-end gap-1 sm:gap-2">
                <div className="flex items-center gap-1">
                    <button onClick={() => onUndoPoint(matchIndex, 'A', isDaihyosen)} disabled={!canUndoA} className="bg-yellow-600 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-yellow-500 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">↶</button>
                    <button onClick={() => onAddPoint(matchIndex, 'A', selectedPointA, isDaihyosen)} disabled={!canAddPointA} className="bg-gray-700 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-gray-600 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">+</button>
                    <select 
                        value={selectedPointA}
                        onChange={(e) => setSelectedPointA(e.target.value as PointType)}
                        disabled={!isMatchActionable}
                        className="bg-gray-200 text-gray-800 text-sm p-1 rounded-md focus:outline-none focus:ring-1 focus:ring-yellow-500 disabled:bg-gray-100 disabled:text-gray-400"
                    >
                        {ALL_POINT_TYPES.map(pt => (
                            <option key={pt} value={pt}>{POINT_TYPE_DETAILS[pt].label}</option>
                        ))}
                    </select>
                </div>
                <div className={`min-w-[60px] ${match.winner === 'A' ? 'text-gray-800 font-bold' : 'text-gray-700'}`}>
                    <IpponDisplay points={pointsA} firstIpponId={firstIpponId} resultText={match.winner === 'A' ? match.resultText : null} />
                </div>
                <div className="border-l-2 border-gray-300 pl-2">
                    <FoulDisplay points={pointsA} />
                </div>
            </div>

            <div className="flex-shrink-0 flex items-center justify-center text-center px-2 sm:px-4">
                <MatchResultMarker winner={match.winner} resultText={match.resultText} />
            </div>

            <div className="flex-1 flex items-center justify-start gap-1 sm:gap-2">
                 <div className="border-r-2 border-gray-300 pr-2">
                    <FoulDisplay points={pointsB} />
                </div>
                 <div className={`min-w-[60px] ${match.winner === 'B' ? 'text-red-500 font-bold' : 'text-red-400/70'}`}>
                    <IpponDisplay points={pointsB} firstIpponId={firstIpponId} resultText={match.winner === 'B' ? match.resultText : null} />
                </div>
                <div className="flex items-center gap-1">
                    <select 
                        value={selectedPointB}
                        onChange={(e) => setSelectedPointB(e.target.value as PointType)}
                        disabled={!isMatchActionable}
                        className="bg-gray-200 text-gray-800 text-sm p-1 rounded-md focus:outline-none focus:ring-1 focus:ring-yellow-500 disabled:bg-gray-100 disabled:text-gray-400"
                    >
                        {ALL_POINT_TYPES.map(pt => (
                            <option key={pt} value={pt}>{POINT_TYPE_DETAILS[pt].label}</option>
                        ))}
                    </select>
                    <button onClick={() => onAddPoint(matchIndex, 'B', selectedPointB, isDaihyosen)} disabled={!canAddPointB} className="bg-red-600 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-red-500 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">+</button>
                    <button onClick={() => onUndoPoint(matchIndex, 'B', isDaihyosen)} disabled={!canUndoB} className="bg-yellow-600 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-yellow-500 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">↶</button>
                </div>
            </div>
        </div>
    )
};


const MatchStatusControl: React.FC<{ status: MatchStatus, onChange: (status: MatchStatus) => void, isFinished: boolean, isKachiNuki: boolean }> = ({ status, onChange, isFinished, isKachiNuki }) => {
    return (
        <select
            value={status}
            onChange={e => onChange(e.target.value as MatchStatus)}
            disabled={isFinished}
            className="text-sm p-1 rounded border bg-[#FFFEFD] border-gray-300 focus:outline-none focus:ring-1 focus:ring-yellow-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
            aria-label="試合結果"
        >
            <option value={MatchStatus.PENDING}>{MATCH_STATUS_TEXT[MatchStatus.PENDING]}</option>
            <option value={MatchStatus.HIKIWAKE}>{isKachiNuki ? '引き分け' : '試合終了'}</option>
            <option value={MatchStatus.ENCHO}>{MATCH_STATUS_TEXT[MatchStatus.ENCHO]}</option>
            {isKachiNuki && <option value={MatchStatus.ENCHO_HIKIWAKE}>{MATCH_STATUS_TEXT[MatchStatus.ENCHO_HIKIWAKE]}</option>}
            <option value={MatchStatus.FUSEN_A_WINS}>{MATCH_STATUS_TEXT[MatchStatus.FUSEN_A_WINS]}</option>
            <option value={MatchStatus.FUSEN_B_WINS}>{MATCH_STATUS_TEXT[MatchStatus.FUSEN_B_WINS]}</option>
            <option value={MatchStatus.HANTEI_A_WINS}>{MATCH_STATUS_TEXT[MatchStatus.HANTEI_A_WINS]}</option>
            <option value={MatchStatus.HANTEI_B_WINS}>{MATCH_STATUS_TEXT[MatchStatus.HANTEI_B_WINS]}</option>
        </select>
    );
};

interface ScoreSheetProps {
    matchTitle: string;
    teamA: SavedTeam;
    teamB: SavedTeam;
    onTeamNameChange: (team: 'A' | 'B', name: string) => void;
    matches: CalculatedMatch[];
    playerPositions: string[];
    daihyosenMatch: CalculatedMatch | null;
    summary: [TeamSummary, TeamSummary];
    winner: CalculatedMatchWinner;
    isFinished: boolean;
    isDaihyosenActive: boolean;
    onPlayerChange: (index: number, team: 'A' | 'B', player: Player, isDaihyosen: boolean) => void;
    onAddPoint: (index: number, player: 'A' | 'B', type: PointType, isDaihyosen: boolean) => void;
    onUndoPoint: (index: number, player: 'A' | 'B', isDaihyosen: boolean) => void;
    onStatusChange: (index: number, status: MatchStatus) => void;
    matchFormat: TeamMatchFormat;
    onMatchFormatChange: (format: TeamMatchFormat) => void;
}

export const ScoreSheet: React.FC<ScoreSheetProps> = (props) => {
    const { matchTitle, teamA, teamB, onTeamNameChange, matches, playerPositions, daihyosenMatch, summary, winner, isFinished, isDaihyosenActive, onPlayerChange, onAddPoint, onUndoPoint, onStatusChange, matchFormat, onMatchFormatChange } = props;

    const allPlayersA = [...teamA.members, ...teamA.substitutes];
    const allPlayersB = [...teamB.members, ...teamB.substitutes];
    
    const matchFormatOptions = [
      { value: 'POINT_MATCH' as TeamMatchFormat, label: '団体戦' },
      { value: 'KACHI_NUKI' as TeamMatchFormat, label: '抜戦' },
    ];

    const renderMatchRow = (match: CalculatedMatch, index: number, isDaihyosen = false) => {
        const isLocked = isDaihyosen 
            ? isFinished 
            : isFinished || isDaihyosenActive || (matchFormat === 'KACHI_NUKI' && index < matches.length - 1);

        const isLoserByForfeitA = match.status === MatchStatus.FUSEN_B_WINS;
        const isLoserByForfeitB = match.status === MatchStatus.FUSEN_A_WINS;
        
        const PlayerDisplay = ({ player, team, availablePlayers }: { player: Player, team: 'A' | 'B', availablePlayers: Player[]}) => (
          <div className="flex flex-col items-center justify-center p-2 h-full">
            {player.affiliation && <div className="text-gray-500 text-xs sm:text-sm truncate w-full">{player.affiliation}</div>}
            <PlayerSelect
                currentPlayer={player}
                availablePlayers={availablePlayers}
                onChange={(newPlayer) => onPlayerChange(index, team, newPlayer, isDaihyosen)}
                isFinished={isLocked}
                className="text-gray-800 text-lg sm:text-xl"
            />
          </div>
        );

        return (
            <React.Fragment key={isDaihyosen ? 'daihyosen' : index}>
                <div className="bg-[#f8f6f2] flex flex-col items-center justify-center gap-1 p-1">
                    <span className="font-bold">
                      {isDaihyosen 
                          ? UI_TEXT.REPRESENTATIVE 
                          : (matchFormat === 'KACHI_NUKI' ? `第${index + 1}試合` : playerPositions[index])
                      }
                    </span>
                    {!isDaihyosen && (
                        <MatchStatusControl
                            status={match.status}
                            onChange={(newStatus) => onStatusChange(index, newStatus)}
                            isFinished={isLocked}
                            isKachiNuki={matchFormat === 'KACHI_NUKI'}
                        />
                    )}
                </div>
                {/* Team A Player (White) */}
                <div className={`relative rounded-md transition-colors ${match.winner === 'A' ? 'bg-[#f2eee9]' : ''} ${isLoserByForfeitA ? 'fusen-loss' : ''}`}>
                   <PlayerDisplay player={match.playerA} team="A" availablePlayers={allPlayersA} />
                </div>
                {/* Score */}
                <div className="min-w-[420px]">
                    <InlineScoreControl
                        match={match}
                        matchIndex={index}
                        isDaihyosen={isDaihyosen}
                        isFinished={isLocked}
                        onAddPoint={onAddPoint}
                        onUndoPoint={onUndoPoint}
                        matchFormat={matchFormat}
                    />
                </div>
                {/* Team B Player (Red) */}
                <div className={`relative rounded-md transition-colors ${match.winner === 'B' ? 'bg-red-100' : ''} ${isLoserByForfeitB ? 'fusen-loss' : ''}`}>
                   <PlayerDisplay player={match.playerB} team="B" availablePlayers={allPlayersB} />
                </div>
            </React.Fragment>
        )
    }

    const teamNameLocked = isFinished || isDaihyosenActive;

    return (
        <div>
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-4">
              <div className="flex-grow">
                {matchTitle && (
                  <h2 className="text-center sm:text-left text-2xl sm:text-3xl font-bold text-gray-700 tracking-wide">
                    {matchTitle}
                  </h2>
                )}
              </div>
              <div className="w-full sm:w-auto sm:min-w-[240px] flex-shrink-0">
                  <label htmlFor="matchFormatSwitch" className="sr-only">試合形式</label>
                  <CustomDropdown
                      id="matchFormatSwitch"
                      options={matchFormatOptions}
                      value={matchFormat}
                      onChange={(v) => onMatchFormatChange(v as TeamMatchFormat)}
                      disabled={isFinished}
                  />
              </div>
            </div>
            
            <div className="overflow-x-auto whitespace-nowrap pb-2">
              <div className="scoresheet-grid text-sm sm:text-base" style={{minWidth: '720px'}}>
                  {/* Header */}
                  <div className="font-bold text-yellow-600 bg-[#f2eee9]">団体名</div>
                  <div className="bg-[#f2eee9]">
                      <EditableCell value={teamA.name} onChange={(name) => onTeamNameChange('A', name)} isFinished={teamNameLocked} className="text-gray-800 text-lg sm:text-xl" />
                  </div>
                  <div className="bg-[#f2eee9] font-bold text-gray-500 text-2xl">VS</div>
                  <div className="bg-[#f2eee9]">
                      <EditableCell value={teamB.name} onChange={(name) => onTeamNameChange('B', name)} isFinished={teamNameLocked} className="text-red-500 text-lg sm:text-xl" />
                  </div>

                  {/* Match Rows */}
                  {matches.map((match, i) => renderMatchRow(match, i))}

                  {/* Summary Row */}
                  <div className="font-bold bg-[#f8f6f2]">{UI_TEXT.SUMMARY}</div>
                  <div>
                    <TeamSummaryDisplay 
                        teamName={teamA.name}
                        summary={summary[0]} 
                        isWinner={winner === 'A'} 
                        isLoser={winner === 'B'}
                        teamColorClass="text-gray-800"
                    />
                  </div>
                  <div className="font-bold text-gray-500"></div>
                  <div>
                    <TeamSummaryDisplay 
                        teamName={teamB.name}
                        summary={summary[1]} 
                        isWinner={winner === 'B'} 
                        isLoser={winner === 'A'}
                        teamColorClass="text-red-500"
                    />
                  </div>

                  {/* Daihyosen Row */}
                  {daihyosenMatch && (
                      renderMatchRow(daihyosenMatch, 0, true)
                  )}
              </div>
            </div>
        </div>
    )
};