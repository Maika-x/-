
import React, { useState, useEffect } from 'react';
import { Match, PointType } from '../types';
import { POINT_TYPE_DETAILS, ALL_POINT_TYPES } from '../constants';

interface ScoreInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  match: Match;
  onUpdate: (updatedMatch: Match) => void;
  teamAName: string;
  teamBName: string;
}

export const ScoreInputModal: React.FC<ScoreInputModalProps> = ({ isOpen, onClose, match, onUpdate, teamAName, teamBName }) => {
  const [currentMatch, setCurrentMatch] = useState(match);
  const [selectedPointA, setSelectedPointA] = useState<PointType>(PointType.MEN);
  const [selectedPointB, setSelectedPointB] = useState<PointType>(PointType.MEN);

  useEffect(() => {
    setCurrentMatch(match);
  }, [match]);

  if (!isOpen) return null;

  const handleScore = (team: 'A' | 'B', point: PointType) => {
    setCurrentMatch(prev => {
        const newMatch = JSON.parse(JSON.stringify(prev));
        const playerPointsCount = newMatch.points.filter(p => p.player === team).length;
        if (playerPointsCount < 2) {
            newMatch.points.push({ id: Date.now(), type: point, player: team });
        }
        return newMatch;
    });
  };

  const handleUndo = (team: 'A' | 'B') => {
    setCurrentMatch(prev => {
        const newMatch = JSON.parse(JSON.stringify(prev));
        let lastPointIndex = -1;
        for (let i = newMatch.points.length - 1; i >= 0; i--) {
            if (newMatch.points[i].player === team) {
                lastPointIndex = i;
                break;
            }
        }
        if (lastPointIndex !== -1) {
            newMatch.points.splice(lastPointIndex, 1);
        }
        return newMatch;
    });
  };

  const handleSave = () => {
    onUpdate(currentMatch);
    onClose();
  };
  
  const renderPlayerDisplay = (team: 'A' | 'B') => {
    const player = team === 'A' ? currentMatch.playerA : currentMatch.playerB;
    const teamName = team === 'A' ? teamAName : teamBName;
    const colorClass = team === 'A' ? 'text-red-400' : 'text-white';
    
    const playerPoints = currentMatch.points.filter(p => p.player === team);
    const firstPointInMatch = currentMatch.points.length > 0 ? currentMatch.points[0] : null;

    const scoreText = playerPoints.map(point => {
        const label = POINT_TYPE_DETAILS[point.type].label;
        if (firstPointInMatch && point.id === firstPointInMatch.id) {
            return `(${label})`;
        }
        return label;
    }).join('');

    return (
        <div className="flex-1 flex flex-col items-center gap-4 p-4 bg-gray-800/70 rounded-lg">
            <h3 className={`text-xl sm:text-2xl font-bold ${colorClass}`}>{player.name}</h3>
            <p className="text-gray-400 text-sm">({teamName})</p>
            <div className="w-full text-center bg-gray-900 rounded-md p-3 min-h-[52px]">
                <span className={`font-mono text-2xl sm:text-3xl font-bold ${colorClass}`}>{scoreText}</span>
            </div>
             <button
                onClick={() => handleUndo(team)}
                disabled={playerPoints.length === 0}
                className="w-full mt-auto bg-yellow-600 text-white font-bold py-2 rounded-md hover:bg-yellow-500 disabled:bg-gray-700 disabled:cursor-not-allowed transition-colors"
            >
                取り消し (Undo)
            </button>
        </div>
    )
  }

  const pointsA = currentMatch.points.filter(p => p.player === 'A').length;
  const pointsB = currentMatch.points.filter(p => p.player === 'B').length;
  const isTeamADisabled = pointsA >= 2;
  const isTeamBDisabled = pointsB >= 2;

  const PointSelect = ({ id, value, onChange, disabled, teamLabel }: { id: string; value: PointType, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, disabled: boolean, teamLabel: string }) => (
      <select
          id={id}
          aria-label={`${teamLabel} point type`}
          value={value}
          onChange={onChange}
          disabled={disabled}
          className="w-full bg-gray-700 text-white p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400 disabled:bg-gray-800"
      >
          {ALL_POINT_TYPES.map(pt => (
              <option key={pt} value={pt}>
                  {POINT_TYPE_DETAILS[pt].label} ({POINT_TYPE_DETAILS[pt].name})
              </option>
          ))}
      </select>
  );

  const AddPointButton = ({ team, selectedPoint, disabled }: { team: 'A' | 'B', selectedPoint: PointType, disabled: boolean }) => (
      <button
          onClick={() => handleScore(team, selectedPoint)}
          disabled={disabled}
          className="w-full bg-blue-600 text-white font-bold py-2 rounded-md hover:bg-blue-500 disabled:bg-gray-700 disabled:cursor-not-allowed transition-colors"
      >
          一本を追加 (Add Ippon)
      </button>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl p-5 sm:p-6 max-w-3xl w-full border-2 border-yellow-400 shadow-2xl">
        <h2 className="text-xl sm:text-2xl font-bold text-center text-yellow-300 mb-4">スコア入力 (Score Input)</h2>
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 my-4 items-stretch">
            {renderPlayerDisplay('A')}
            
            {/* Central Controls */}
            <div className="flex sm:flex-col justify-around items-center gap-4 p-4 bg-gray-900/50 rounded-lg">
                <div className="w-full flex flex-col gap-2 items-center">
                    <label htmlFor="point-select-a" className="font-bold text-red-400">{teamAName}</label>
                    <PointSelect 
                        id="point-select-a"
                        value={selectedPointA}
                        onChange={(e) => setSelectedPointA(e.target.value as PointType)}
                        disabled={isTeamADisabled}
                        teamLabel={teamAName}
                    />
                    <AddPointButton team="A" selectedPoint={selectedPointA} disabled={isTeamADisabled} />
                </div>
                
                <div className="text-2xl font-bold text-gray-500">VS</div>
                
                <div className="w-full flex flex-col gap-2 items-center">
                      <label htmlFor="point-select-b" className="font-bold text-white">{teamBName}</label>
                    <PointSelect
                        id="point-select-b"
                        value={selectedPointB}
                        onChange={(e) => setSelectedPointB(e.target.value as PointType)}
                        disabled={isTeamBDisabled}
                        teamLabel={teamBName}
                    />
                    <AddPointButton team="B" selectedPoint={selectedPointB} disabled={isTeamBDisabled} />
                </div>
            </div>

            {renderPlayerDisplay('B')}
        </div>
        <button
            onClick={handleSave}
            className="w-full mt-4 bg-green-600 text-white font-bold py-3 text-lg rounded-lg hover:bg-green-500 transition-colors"
        >
            完了 (Done)
        </button>
      </div>
    </div>
  );
};
