
import React, { useState } from 'react';
import { CalculatedIndividualMatch, PointType, MatchStatus, CalculatedMatchWinner, ScoredPoint, Player, TournamentInfo } from '../types';
import { POINT_TYPE_DETAILS, ALL_POINT_TYPES, MATCH_STATUS_TEXT } from '../constants';

// --- Reusable Helper Components (adapted from ScoreSheet) ---

const IpponDisplay: React.FC<{ points: ScoredPoint[], firstIpponId: number | null, resultText: string | null }> = ({ points, firstIpponId, resultText }) => {
    if (points.some(p => p.type === PointType.FUSEN)) {
        return <div className="flex items-center justify-center h-8"><span className="font-bold text-lg inline-flex items-center justify-center">○○</span></div>;
    }
    const ippons = points.filter(p => p.type !== PointType.HANSOKU);
    const showVerticalText = resultText === '一本勝';
    return (
        <div className="flex items-center justify-center h-8 space-x-1">
            <div className="flex items-center justify-center space-x-2">
                {ippons.map((point) => {
                    const details = POINT_TYPE_DETAILS[point.type];
                    if (!details) return null;
                    const isFirst = point.id === firstIpponId;
                    return <span key={point.id} className={`inline-flex items-center justify-center w-6 h-6 sm:w-7 sm:h-7 text-sm font-bold ${isFirst ? 'border-2 border-current rounded-full' : ''}`} title={details.name}>{details.label}</span>;
                })}
            </div>
            {showVerticalText && <div style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }} className="text-xs font-bold text-gray-500 h-full flex items-center">{resultText}</div>}
        </div>
    );
};

const FoulDisplay: React.FC<{ points: ScoredPoint[] }> = ({ points }) => {
    const fouls = points.filter(p => p.type === PointType.HANSOKU);
    return <div className="flex items-center justify-center h-6 space-x-1" aria-label={`Fouls: ${fouls.length}`}>{fouls.map(foul => <span key={foul.id} className="text-xl text-gray-800" title="Hansoku">▲</span>)}</div>;
};

const MatchResultMarker: React.FC<{ winner: CalculatedMatchWinner, resultText: string | null }> = ({ winner, resultText }) => {
    const isEncho = resultText === MATCH_STATUS_TEXT[MatchStatus.ENCHO] || resultText === MATCH_STATUS_TEXT[MatchStatus.ENCHO_HIKIWAKE];
    const MarkerContent = () => {
        if (resultText && winner !== 'Draw' && !isEncho && resultText !== '一本勝') {
            return <div className="w-full h-full flex items-center justify-center font-bold text-gray-700 text-sm sm:text-lg" aria-label={resultText}>{resultText}</div>;
        }
        if (winner === 'Draw') {
            return <div className="relative w-full h-full" aria-label="Draw"><div className="absolute top-1/2 left-0 w-full h-1 bg-red-500 transform -translate-y-1/2 rotate-45 rounded-full"></div><div className="absolute top-1/2 left-0 w-full h-1 bg-red-500 transform -translate-y-1/2 -rotate-45 rounded-full"></div></div>;
        }
        const boxClasses = "flex items-center justify-center w-full h-full border-2 rounded-lg overflow-hidden";
        const winnerBoxClasses = `${boxClasses} border-gray-400`;
        const pendingBoxClasses = `${boxClasses} border-gray-300`;
        return (
            <div className={winner === null ? pendingBoxClasses : winnerBoxClasses}>
                <div className={`flex-1 h-full flex items-center justify-center border-r-2 ${winner === null ? 'border-gray-300' : 'border-gray-400'}`}>{winner === 'A' && <span className="text-gray-800 font-extrabold text-3xl sm:text-4xl">○</span>}</div>
                <div className="flex-1 h-full flex items-center justify-center">{winner === 'B' && <span className="text-red-500 font-extrabold text-3xl sm:text-4xl">○</span>}</div>
            </div>
        );
    };
    return (
        <div className="relative w-16 sm:w-20 h-10 flex items-center justify-center">
            {isEncho && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-500 text-white text-xs font-bold px-2 py-0.5 rounded-full shadow z-10">{MATCH_STATUS_TEXT[MatchStatus.ENCHO]}</div>}
            <MarkerContent />
        </div>
    );
};

const InlineScoreControl: React.FC<{
    match: CalculatedIndividualMatch;
    isFinished: boolean;
    onAddPoint: (player: 'A' | 'B', type: PointType) => void;
    onUndoPoint: (player: 'A' | 'B') => void;
}> = ({ match, isFinished, onAddPoint, onUndoPoint }) => {
    const [selectedPointA, setSelectedPointA] = useState<PointType>(PointType.MEN);
    const [selectedPointB, setSelectedPointB] = useState<PointType>(PointType.MEN);
    
    const ippons = match.points.filter(p => p.type !== PointType.HANSOKU);
    const firstIpponInMatch = ippons.length > 0 ? ippons.reduce((earliest, current) => current.id < earliest.id ? current : earliest) : null;
    const firstIpponId = firstIpponInMatch?.id ?? null;

    const pointsA = match.points.filter(p => p.player === 'A');
    const pointsB = match.points.filter(p => p.player === 'B');
    
    const isMatchActionable = !isFinished && (match.status === MatchStatus.PENDING || match.status === MatchStatus.ENCHO);
    const pointLimit = match.matchType === 'SANBON' ? 2 : 1;

    const directIpponsA = pointsA.filter(p => p.type !== PointType.HANSOKU).length;
    const canScoreMoreIpponA = directIpponsA < pointLimit;
    const canAddPointA = isMatchActionable && (selectedPointA === PointType.HANSOKU || canScoreMoreIpponA);
    const canUndoA = pointsA.length > 0 && isMatchActionable;

    const directIpponsB = pointsB.filter(p => p.type !== PointType.HANSOKU).length;
    const canScoreMoreIpponB = directIpponsB < pointLimit;
    const canAddPointB = isMatchActionable && (selectedPointB === PointType.HANSOKU || canScoreMoreIpponB);
    const canUndoB = pointsB.length > 0 && isMatchActionable;

    return (
        <div className="w-full h-full flex items-center justify-between gap-1 sm:gap-2 px-1">
            <div className="flex-1 flex items-center justify-end gap-1 sm:gap-2">
                <div className="flex items-center gap-1">
                    <button onClick={() => onUndoPoint('A')} disabled={!canUndoA} className="bg-yellow-600 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-yellow-500 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">↶</button>
                    <button onClick={() => onAddPoint('A', selectedPointA)} disabled={!canAddPointA} className="bg-gray-700 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-gray-600 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">+</button>
                    <select value={selectedPointA} onChange={(e) => setSelectedPointA(e.target.value as PointType)} disabled={!isMatchActionable} className="bg-gray-200 text-gray-800 text-sm p-1 rounded-md focus:outline-none focus:ring-1 focus:ring-yellow-500 disabled:bg-gray-100 disabled:text-gray-400">
                        {ALL_POINT_TYPES.map(pt => <option key={pt} value={pt}>{POINT_TYPE_DETAILS[pt].label}</option>)}
                    </select>
                </div>
                <div className={`min-w-[60px] ${match.winner === 'A' ? 'text-gray-800 font-bold' : 'text-gray-700'}`}>
                    <IpponDisplay points={pointsA} firstIpponId={firstIpponId} resultText={match.winner === 'A' ? match.resultText : null} />
                </div>
                <div className="border-l-2 border-gray-300 pl-2"><FoulDisplay points={pointsA} /></div>
            </div>
            <div className="flex-shrink-0 flex items-center justify-center text-center px-2 sm:px-4">
                <MatchResultMarker winner={match.winner} resultText={match.resultText} />
            </div>
            <div className="flex-1 flex items-center justify-start gap-1 sm:gap-2">
                 <div className="border-r-2 border-gray-300 pr-2"><FoulDisplay points={pointsB} /></div>
                 <div className={`min-w-[60px] ${match.winner === 'B' ? 'text-red-500 font-bold' : 'text-red-400/70'}`}>
                    <IpponDisplay points={pointsB} firstIpponId={firstIpponId} resultText={match.winner === 'B' ? match.resultText : null} />
                </div>
                <div className="flex items-center gap-1">
                    <select value={selectedPointB} onChange={(e) => setSelectedPointB(e.target.value as PointType)} disabled={!isMatchActionable} className="bg-gray-200 text-gray-800 text-sm p-1 rounded-md focus:outline-none focus:ring-1 focus:ring-yellow-500 disabled:bg-gray-100 disabled:text-gray-400">
                        {ALL_POINT_TYPES.map(pt => <option key={pt} value={pt}>{POINT_TYPE_DETAILS[pt].label}</option>)}
                    </select>
                    <button onClick={() => onAddPoint('B', selectedPointB)} disabled={!canAddPointB} className="bg-red-600 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-red-500 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">+</button>
                    <button onClick={() => onUndoPoint('B')} disabled={!canUndoB} className="bg-yellow-600 w-7 h-7 rounded flex items-center justify-center text-white font-bold hover:bg-yellow-500 disabled:bg-gray-200 disabled:text-gray-400 transition-colors">↶</button>
                </div>
            </div>
        </div>
    )
};

const MatchStatusControl: React.FC<{ status: MatchStatus, onChange: (status: MatchStatus) => void, isFinished: boolean }> = ({ status, onChange, isFinished }) => {
    return (
        <select value={status} onChange={e => onChange(e.target.value as MatchStatus)} disabled={isFinished} className="text-sm p-1 rounded border bg-[#FFFEFD] border-gray-300 focus:outline-none focus:ring-1 focus:ring-yellow-500 disabled:bg-gray-100 disabled:cursor-not-allowed" aria-label="試合結果">
            <option value={MatchStatus.PENDING}>{MATCH_STATUS_TEXT[MatchStatus.PENDING]}</option>
            <option value={MatchStatus.HIKIWAKE}>試合終了 (Finish)</option>
            <option value={MatchStatus.ENCHO}>{MATCH_STATUS_TEXT[MatchStatus.ENCHO]}</option>
            <option value={MatchStatus.FUSEN_A_WINS}>{MATCH_STATUS_TEXT[MatchStatus.FUSEN_A_WINS]}</option>
            <option value={MatchStatus.FUSEN_B_WINS}>{MATCH_STATUS_TEXT[MatchStatus.FUSEN_B_WINS]}</option>
            <option value={MatchStatus.HANTEI_A_WINS}>{MATCH_STATUS_TEXT[MatchStatus.HANTEI_A_WINS]}</option>
            <option value={MatchStatus.HANTEI_B_WINS}>{MATCH_STATUS_TEXT[MatchStatus.HANTEI_B_WINS]}</option>
        </select>
    );
};

// --- Main Component ---

interface IndividualScoreboardProps {
  match: CalculatedIndividualMatch;
  onAddPoint: (player: 'A' | 'B', type: PointType) => void;
  onUndoPoint: (player: 'A' | 'B') => void;
  onStatusChange: (status: MatchStatus) => void;
  onShowResultModal: () => void;
  onSaveAndReset: (finalResult: string) => void;
  onEdit: () => void;
  isFinished: boolean;
  onAnalysis: () => void;
  analysis: string | null;
  isAnalyzing: boolean;
  showResultModal: boolean;
  onCloseResultModal: () => void;
  onTournamentInfoChange: (field: keyof TournamentInfo, value: string) => void;
}

export const IndividualScoreboard: React.FC<IndividualScoreboardProps> = ({ 
    match, onAddPoint, onUndoPoint, onStatusChange, onShowResultModal, onSaveAndReset, onEdit, isFinished,
    onAnalysis, analysis, isAnalyzing, showResultModal, onCloseResultModal, onTournamentInfoChange
}) => {
  
  const [finalResult, setFinalResult] = useState('');
  const { playerA, playerB, tournamentInfo, winner, matchType } = match;
  const winnerText = winner === 'A' ? `${playerA.name}の勝利！` : winner === 'B' ? `${playerB.name}の勝利！` : winner === 'Draw' ? '引き分け' : '試合結果';

  return (
    <div className="bg-[#f8f6f2] min-h-screen">
       <datalist id="final-results-list">
        <option value="優勝" />
        <option value="準優勝" />
        <option value="三位" />
        <option value="ベスト8" />
        <option value="ベスト16" />
        <option value="敢闘賞" />
        <option value="予選リーグ敗退" />
      </datalist>
      <div className="max-w-7xl mx-auto p-2 sm:p-4 md:p-6 lg:p-8">
        <header className="text-center mb-6">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-gray-800 tracking-tight">{tournamentInfo.name}</h1>
          
          {isFinished && tournamentInfo.round ? (
            <p className="text-lg sm:text-xl text-gray-600 font-bold mt-2">{tournamentInfo.round}</p>
          ) : (
            <div className="mt-2 flex justify-center items-center gap-2">
              <label htmlFor="round-input" className="text-lg sm:text-xl text-gray-600 font-bold">回戦:</label>
              <input
                id="round-input"
                type="text"
                value={tournamentInfo.round || ''}
                placeholder="例: 一回戦、決勝"
                disabled={isFinished}
                onChange={(e) => onTournamentInfoChange('round', e.target.value)}
                list="round-options-list"
                className="px-3 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 bg-white text-lg sm:text-xl text-gray-600 font-bold text-center w-48"
              />
              <datalist id="round-options-list">
                  <option value="予選リーグ" />
                  <option value="一回戦" />
                  <option value="二回戦" />
                  <option value="三回戦" />
                  <option value="四回戦" />
                  <option value="五回戦" />
                  <option value="六回戦" />
                  <option value="七回戦" />
                  <option value="準々決勝" />
                  <option value="準決勝" />
                  <option value="決勝" />
                  <option value="順位決定戦" />
              </datalist>
            </div>
          )}

          <p className="text-base sm:text-lg text-gray-500 mt-2">{tournamentInfo.date} @ {tournamentInfo.venue}</p>
          <p className="text-sm text-gray-500 mt-1">({matchType === 'SANBON' ? '三本勝負' : '一本勝負'})</p>
        </header>

        <main className="bg-[#FFFEFD] rounded-2xl shadow-lg p-3 sm:p-6">
           <div className="overflow-x-auto whitespace-nowrap pb-2">
              <div className="scoresheet-grid text-sm sm:text-base" style={{minWidth: '720px'}}>
                  {/* Header */}
                  <div className="font-bold text-yellow-600 bg-[#f2eee9]">選手</div>
                  <div className="bg-[#f2eee9] font-bold text-gray-800 text-lg sm:text-xl">白</div>
                  <div className="bg-[#f2eee9] font-bold text-gray-500 text-2xl">VS</div>
                  <div className="bg-[#f2eee9] font-bold text-red-500 text-lg sm:text-xl">赤</div>

                  {/* Match Row */}
                  <div className="bg-[#f8f6f2] flex flex-col items-center justify-center gap-1 p-1">
                      <span className="font-bold">試合</span>
                      <MatchStatusControl status={match.status} onChange={onStatusChange} isFinished={isFinished} />
                  </div>
                  <div className={`flex flex-col items-center justify-center p-2 transition-colors ${winner === 'A' ? 'bg-gray-200' : ''}`}>
                      {playerA.affiliation && <div className="text-gray-500 text-sm">{playerA.affiliation}</div>}
                      <div className="text-gray-800 text-lg sm:text-xl font-bold">{playerA.name}</div>
                  </div>
                  <div className="min-w-[420px]">
                      <InlineScoreControl match={match} isFinished={isFinished} onAddPoint={onAddPoint} onUndoPoint={onUndoPoint} />
                  </div>
                   <div className={`flex flex-col items-center justify-center p-2 transition-colors ${winner === 'B' ? 'bg-red-100' : ''}`}>
                      {playerB.affiliation && <div className="text-gray-500 text-sm">{playerB.affiliation}</div>}
                      <div className="text-gray-800 text-lg sm:text-xl font-bold">{playerB.name}</div>
                  </div>
              </div>
            </div>
        </main>
          
        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
              <button onClick={() => onSaveAndReset('')} className="w-full sm:w-auto px-6 py-2.5 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-colors">
                トップに戻る (Back to Top)
              </button>
            </div>
            <div className="flex flex-col sm:flex-row justify-end items-center gap-4 w-full sm:w-auto">
              {isFinished ? (
                <button onClick={onEdit} className="w-full sm:w-auto px-6 py-2.5 text-base sm:text-lg sm:px-8 sm:py-3 bg-gray-600 text-white font-bold rounded-lg shadow-md hover:bg-gray-700 transition-colors">
                  試合を編集 (Edit Match)
                </button>
              ) : (
                <button onClick={onShowResultModal} disabled={winner === null} className="w-full sm:w-auto px-6 py-2.5 text-base sm:text-lg sm:px-8 sm:py-3 bg-green-600 text-white font-bold rounded-lg shadow-md hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">
                  試合終了 (Finish Match)
                </button>
              )}
            </div>
        </div>
        
        <footer className="text-center mt-6 sm:mt-8 text-gray-500 text-sm">
          <p>Created by Maika</p>
        </footer>
      </div>
      
      {/* Result Modal */}
      {showResultModal && (
         <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
              <div className="bg-[#FFFEFD] text-gray-800 rounded-xl p-5 sm:p-8 max-w-md w-full border-2 border-yellow-400 shadow-2xl">
                <h2 className="text-2xl sm:text-3xl font-bold text-center text-yellow-500 mb-4">試合結果</h2>
                 <div className="text-center my-6">
                    <p className={`text-2xl sm:text-4xl font-bold ${winner === 'A' ? 'text-gray-800' : winner === 'B' ? 'text-red-500' : 'text-yellow-500'}`}>{winnerText}</p>
                </div>
                 <div className="flex justify-around text-center mb-6 sm:mb-8 text-sm sm:text-base">
                    <div>
                        <h3 className="text-lg sm:text-xl font-bold text-gray-800">{playerA.name}</h3>
                        {playerA.affiliation && <p className="text-sm text-gray-500 -mt-1 mb-1">{playerA.affiliation}</p>}
                        <p>取得本数: {match.pointsA}</p>
                    </div>
                    <div>
                        <h3 className="text-lg sm:text-xl font-bold text-red-500">{playerB.name}</h3>
                        {playerB.affiliation && <p className="text-sm text-gray-500 -mt-1 mb-1">{playerB.affiliation}</p>}
                        <p>取得本数: {match.pointsB}</p>
                    </div>
                </div>
                <div className="mb-4">
                    <label htmlFor="finalResult" className="block text-sm font-bold text-gray-600 mb-1 text-center">最終成績 (任意)</label>
                    <input
                        id="finalResult"
                        type="text"
                        value={finalResult}
                        onChange={(e) => setFinalResult(e.target.value)}
                        list="final-results-list"
                        placeholder="例: 優勝、三位"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                </div>
                 <div className="flex flex-col gap-3">
                    {winner && !analysis && (
                       <button onClick={onAnalysis} disabled={isAnalyzing} className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold py-2.5 px-4 rounded-lg hover:from-purple-600 hover:to-indigo-700 transition-all text-base sm:text-lg shadow-md disabled:opacity-50 disabled:cursor-wait">
                        {isAnalyzing ? '分析中...' : 'AIによる分析'}
                      </button>
                    )}
                    {analysis && !isAnalyzing && (
                        <div className="mt-2 p-4 bg-[#f8f6f2] rounded-lg border border-gray-200 animate-fade-in">
                            <h4 className="font-bold text-purple-700 mb-2">AI 分析</h4>
                            <p className="text-gray-700 whitespace-pre-wrap text-sm">{analysis}</p>
                        </div>
                    )}
                    <button onClick={onEdit} className="w-full bg-orange-500 text-white font-bold py-2.5 px-4 rounded-lg hover:bg-orange-600 transition-colors text-base sm:text-lg">
                      試合を編集
                    </button>
                    <button onClick={() => onSaveAndReset(finalResult)} className="w-full bg-blue-600 text-white font-bold py-2.5 px-4 rounded-lg hover:bg-blue-500 transition-colors text-base sm:text-lg">
                      保存して新しい試合へ
                    </button>
                    <button onClick={onCloseResultModal} className="w-full bg-gray-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-500 transition-colors">
                      閉じる
                    </button>
                </div>
              </div>
            </div>
      )}
    </div>
  );
};
